#include <iostream>
#include <windows.h>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <filesystem>
#include <fstream>
#include <utility>
#include <cstdlib>
#include <map>
#include <filesystem>
using namespace std;

bool access = false;
bool Admin = false;
string currentUser = "";

vector<pair<string, vector<string>>> read_csv(string filename) {
    ifstream file(filename);
    vector<pair<string, vector<string>>> result;
    string line;
    string cell;
    vector<string> values;
    while (getline(file, line)) {
        stringstream lineStream(line);
        while (getline(lineStream, cell, ',')) {
            values.push_back(cell);
        }
        result.push_back(make_pair(values.at(0), values));
        values.clear();
    }
    return result;
}

//will check for a number use instead of cin
int validInput()
{
    int x;
    cin >> x;
    while (cin.fail())
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Bad entry.  Enter a NUMBER: ";
        cin >> x;
    }
    cout << endl;
    return x;
}

int weekly_menu() { // TODO, once the user choses a value input it into a file.
    cout << "please choose a day of the week for your order:" << endl;

    int day_choice;
    string day;

    while (true) {
        cout << endl;
        cout << "1. Monday" << endl;
        cout << "2. Tuesday" << endl;
        cout << "3. Wednesday" << endl;
        cout << "4. Thursday" << endl;
        cout << "5. Friday" << endl;

        cout << "\nplease enter your choice: ";
        cin >> day_choice;

        if (day_choice > 4 or day_choice < 0) {
            cout << "please enter a number between 1 and 5\n";
            Sleep(2000);
            system("CLS");
            continue;
        }

        if (day_choice == 1) {
            cin.clear();
            day = "monday";
            cout << "you chose monday" << endl;
        }
        else if (day_choice == 2) {
            cin.clear();
            day = "tuesday";
            cout << "you chose tuesday" << endl;
        }
        else if (day_choice == 3) {
            cin.clear();
            day = "wednesday";
            cout << "you chose wednesday" << endl;
        }
        else if (day_choice == 4) {
            cin.clear();
            day = "thursday";
            cout << "you chose thursday" << endl;
        }
        else if (day_choice == 5) {
            cin.clear();
            day = "friday";
            cout << "you chose friday" << endl;
        }
        else {
            validInput();
            continue;
        }
         break;
    }

    vector<pair<string, vector<string>>> result = read_csv("Order.csv");
    for (int i = 0; i < result.size(); i++) {
        if (result.at(i).first == day) {
            cout << "youve already chosen " << day;
            Sleep(3000);
            system("CLS");
            return(0);
        }
    }

    map<string, int> menu;
    menu.insert(pair<string, int>("burger", 12));
    menu.insert(pair<string, int>("cake", 7));
    menu.insert(pair<string, int>("pizza", 10));
    menu.insert(pair<string, int>("soda", 4));

    cout << endl;
    cout << "weekly menu:";
    cout << endl;
    map <string, int> ::iterator iter;


    string order{};
    while (true) {
        for (auto pair : menu) {
            cout << pair.first << " " << "$" << pair.second << endl;
        }

        int food_choice;
        cout << "\nplease enter your choice 1-4: ";
        cin >> food_choice;
        if (food_choice > 4 or food_choice < 0) {
            cout << "please enter a number between 1 and 4\n";
            Sleep(2000);
            system("CLS");
            continue;
        }

        if (food_choice == 1) {
            cin.clear();
            order = "burger";
            cout << "you ordered a burger" << endl;
        }
        else if (food_choice == 2) {
            cin.clear();
            order = "cake";
            cout << "you ordered a cake" << endl;
        }
        else if (food_choice == 3) {
            cin.clear();
            order = "pizza";
            cout << "you ordered a pizza" << endl;
        }
        else if (food_choice == 4) {
            cin.clear();
            order = "soda";
            cout << "you ordered a soda" << endl;
        }
        else {
            validInput();
            continue;
        }
        break;
    }

    // Open the file in append mode
    ofstream outFile("Order.csv", ios::app);
    if (!outFile) {
        cerr << "Error opening file for writing\n";
        return(0);
    }

    //write user information to the file
    outFile << day << "," << order << "\n";

    //close the file
    outFile.close();

    //Confirmation message
    cout << "order successful\n";
    Sleep(3000);
    system("CLS");


    while (true) {
        cout << "do you want to chose another food item/day? (y/n): " << endl;
        string y_or_n;
        cin >> y_or_n;

        for (int i = 0; i < y_or_n.length(); i++) {
            y_or_n[i] = tolower(y_or_n[i]);
        }

        if (y_or_n == "y") {
            weekly_menu();
        }
        else if (y_or_n == "n") {
            return(0);
        }
        else {
            cout << "please input the letter y or n" << endl;
            continue;
        }
    }

    cout << endl;
    return(0);
}


void discounts_for_sub() { 

}


void details() {
    // Information about the school/office. also about locations and addresses also phone numbers of the office workers etc...
    cout << "welcome to the ";

}


void registerUser() {
    //Get user name from user
    string RegUsername, RegPassword;
    char AdminAccess;
    string ADM = "";
    cout << "Enter username: ";
    cin.ignore(1000, '\n');
    cin.clear();
    getline(cin, RegUsername);

    //Checking to make sure the currently entered username doesn't already exist
    vector<pair<string, vector<string>>> result = read_csv("Accounts.csv");
    for (int i = 0; i < result.size(); i++) {
        if (result.at(i).first == RegUsername) {
            cout << "Username " << RegUsername << " Already exists";
            Sleep(3000);
            system("CLS");
            return;
        }
    }
    //Getting password from the user
    cout << "Enter password: ";
    cin.clear();
    getline(cin, RegPassword);

    // Open the file in append mode
    ofstream outFile("Accounts.csv", ios::app);
    if (!outFile) {
        cerr << "Error opening file for writing\n";
        return;
    }

    //Asking the user if they would like admin access
    if (Admin == true) {
        while (true) {
            cout << "Would you like to give this account admin access (y/n): ";
            cin >> AdminAccess;
            if (AdminAccess == 'Y' || AdminAccess == 'y') {
                ADM = "1";
                break;
            }

            else if (AdminAccess == 'N' || AdminAccess == 'n') {
                ADM = "0";
                break;
            }

            else {
                cout << "Invalid option";
            }
        }
    }

    else if (Admin == false) {
        ADM = "0";
    }

    //write user information to the file
    outFile << RegUsername << "," << RegPassword << "," << ADM << "\n";

    //close the file
    outFile.close();

    //Confirmation message
    cout << "User registration successful\n";
    Sleep(3000);
    system("CLS");
}


void login() {
    string username2, password2;
    //Get user name from user
    cin.ignore(1000, '\n');
    cin.clear();
    cout << "Enter username: ";
    cin.clear();
    getline(cin, username2);
    //Getting password from the user
    cout << "Enter password: ";
    cin.clear();
    getline(cin, password2);

    cin.clear();

    //uses readcsv function to read the csv file
    vector<pair<string, vector<string>>> result = read_csv("Accounts.csv");
    //loops through the vector of pairs to check if the username and password match
    string actualUsername = "";
    string actualPassword = "";
    string ActualAdmin = "";
    for (int i = 0; i < result.size(); i++) {
        if (result.at(i).first == username2) {
            actualUsername = result.at(i).first;
            actualPassword = result.at(i).second.at(1);
            ActualAdmin = result.at(i).second.at(2);
        }

    }

    if (username2 == actualUsername && password2 == actualPassword) {
        cout << "Login succesful" << endl;
        currentUser = username2;
        access = true;
        if (ActualAdmin == "1") {
            Admin = true;
            cout << "Admin Access granted";
        }
        Sleep(3000);
        system("CLS");
    }

    else {
        cout << "Login failed" << endl;
        Sleep(3000);
        system("CLS");
    }

    return;

}

void accoutManage() {
    int option2;
    while (true) {
        cout << "Login/Registration" << endl;
        cout << "\n";
        cout << "1: Login" << endl;
        cout << "2: Create account" << endl;
        cout << "3: Log out" << endl;
        cout << "4: Exit" << endl;
        cout << "please enter the input for what you'd like to do: ";
        cin >> option2;

        //Selecting an option

        switch (option2) {
        case 1:
            //User chooses to log in
            if (access == false) {
                system("CLS");
                login();
                break;
            }
            else if (access == true) {
                cout << "Already logged in";
                Sleep(3000);
                system("CLS");
                break;
            }

        case 2:
            //user chooses to create an accout
            registerUser();
            access = true;
            break;

        case 3:
            if (access == true) {
                cout << "Logged out";
                access = false;
                Sleep(3000);
                system("CLS");
                break;
            }

            else if (access == false) {
                cout << "Not currently signed in";
                Sleep(3000);
                system("CLS");
                break;
            }

        case 4:
            //User wants to exit
            system("CLS");
            return;

        default:
            cout << "invalid input";
            break;
        }
    }
}

int main() {
    cout << "Welcome to the school lunch ordering system! \n";
    cout << endl;


    while (true) {

        cout << "1. weekly menu \n";
        cout << "2. discounts for term subscription \n";
        cout << "3. Contact details and office locations. \n";
        cout << "4. Login and registration\n";
        cout << "5. quit \n";

        cout << "\nplease enter your choice: ";
        int menu_choice = NULL;
        cin >> menu_choice;

        if (menu_choice > 5 or menu_choice < 0) {
            cout << "please enter a number between 1 and 5\n";
            Sleep(1500);
            system("CLS");
            continue;
        }

        if (menu_choice == 1) {
            system("CLS");
            weekly_menu();
            break;
        }
        else if (menu_choice == 2) {
            system("CLS");
            discounts_for_sub();
            break;
        }
        else if (menu_choice == 3) {
            system("CLS");
            details();
            break;
        }
        else if (menu_choice == 4) {
            system("CLS");
            accoutManage();
            break;
        }
        else if (menu_choice == 5) {
            system("CLS");
            exit(0);
            break;
        }
        else {
            validInput();
        }
    }
}
