#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <cstdlib>
using namespace std;

/*
* INPUTING A VALUE INTO A FILE:
*
* ofstream file("FILE NAME.txt");
* file << VARIABLE NAME;
* file.close();
*
* GETTING A VALUE FROM A FILE:
*
* ifstream file("FILE NAME.txt");
* string VARIABLE NAME;
* file >> VARIABLE NAME;
* cout << "something " << VARIABLE NAME;
* file.close();
*
* INPUTING MULTIPLE VALUES INTO A FILE:
*
* ofstream file("FILE NAME.txt");
*
* for(string VARIABLE NAME : VARIABLE NAME) {
*   file << VARIABLE NAME << endl;
* }
* file.close();
*
* GETTING MULTIPLE VALUEs FROM A FILE:
*
* ifstream file("FILE NAME.txt");
* while(file >> VARIABLE NAME) {
*   VARIABLE NAME.push_back(VARIABLE NAME);
* }
* cout <<  VARIABLE NAME
* file.close();
*/


int weekly_menu() { // TODO, once the user choses a value input it into a file.
    map<string, int> menu;
    menu.insert(pair<string, int>("burger", 12));
    menu.insert(pair<string, int>("cake", 7));
    menu.insert(pair<string, int>("pizza", 10));
    menu.insert(pair<string, int>("soda", 4));

    cout << endl;
    cout << "weekly menu:";
    cout << endl;
    map <string, int> ::iterator iter;

    for (auto pair : menu) {
        cout << pair.first << " " << "$" << pair.second << endl;
    }
    int order{};
    while (true) {
        int menu_choice;
        cout << "\nplease enter your choice 1-4: ";
        cin >> menu_choice;

        if (menu_choice == 1) {
            order = menu["burger"];
            cout << "you ordered a pizza" << endl;
        }
        else if (menu_choice == 2) {
            order = menu["cake"];
            cout << "you ordered a burger" << endl;
        }
        else if (menu_choice == 3) {
            order = menu["pizza"];
            cout << "you ordered a cake" << endl;
        }
        else if (menu_choice == 4) {
            order = menu["soda"];
            cout << "you ordered a soda" << endl;
        }
        else {
            cout << "please input a number between 1 and 4\n";
            continue;
        }
        break;
    }
    cout << endl;
    return(0);
}


void discounts_for_sub() {

}


void details() {

}


void login_registration() {

}


int main()
{
    cout << "Welcome to the school lunch ordering system! \n";
    cout << endl;


    while (true) {

        cout << "1. weekly menu \n";
        cout << "2. discounts for term subscription \n";
        cout << "3. Contacts details and office locations. \n";
        cout << "4. Login and registration option for the (parents / staff) \n";
        cout << "5. quit \n";

        int menu_choice;

        try {
            cout << "\nplease enter your choice: ";
            cin >> menu_choice;

            switch (menu_choice) {
            case 1:
                weekly_menu();
                break;
            case 2:
                discounts_for_sub();
                break;
            case 3:
                details();
                break;
            case 4:
                login_registration();
                break;
            case 5:
                exit(0);
                break;
            default:
                throw menu_choice; // check if menu_choice is a int or string and throw to catch accordingly
            }
        }
        catch (int myNum) {
            cout << "please input a number between 1 and 5\n"; 
        }
        catch (string myNum) {
            cout << "please input a number between 1 and 5\n";
        }
    }
}

