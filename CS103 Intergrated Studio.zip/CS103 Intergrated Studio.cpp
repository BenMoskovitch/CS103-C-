#include <iostream>
#include <string>
#include <map>
#include <fstream>
using namespace std;

/*
* INPUTING A VALUE INTO A FILE:
* 
* ofstream file("FILE NAME.txt");
* file << VARIABLE NAME;
* file.close();
* 
* GETTING A VALUE FROM A FILE:
* 
* ifstream file("FILE NAME.txt");
* string VARIABLE NAME;
* file >> VARIABLE NAME;
* cout << "something " << VARIABLE NAME;
* file.close();
* 
* INPUTING MULTIPLE VALUES INTO A FILE:
* 
* ofstream file("FILE NAME.txt");
* 
* for(string VARIABLE NAME : VARIABLE NAME) {
*   file << VARIABLE NAME << endl;
* }
* file.close();
* 
* GETTING MULTIPLE VALUEs FROM A FILE:
* 
* ifstream file("FILE NAME.txt");
* while(file >> VARIABLE NAME) {
*   VARIABLE NAME.push_back(VARIABLE NAME);
* }
* cout <<  VARIABLE NAME
* file.close();
*/


void weekly_menu() {
    map<string, float> food;
    food.insert(pair<string, float>("pizza", 10));
    food.insert(pair<string, float>("burger", 12));
    food.insert(pair<string, float>("cake", 7));
    food.insert(pair<string, float>("soda", 4));

    cout << endl;
    map <string, float> ::iterator iter;

    for (auto pair : food) {
        cout << pair.first << " " << "$" << pair.second << endl;
    }

    while (true) {
        int menu_choice;
        cout << "please enter your choice: ";
        cin >> menu_choice;

        switch (menu_choice) {
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
            
            break;
        default:
            cout << "please input a number \n"; // crashes when you try to input a letter/string
            continue;
        }
        break;
    }
}


void discounts_for_sub() {

}


void details() {

}


void login_registration() {

}


int main()
{ 

    cout << "Welcome to the school lunch ordering system! \n";
    cout << endl;

    cout << "1. weekly menu \n";
    cout << "2. discounts for term subscription \n";
    cout << "3. Contacts details and office locations. \n";
    cout << "4. Login and registration option for the (parents / staff) \n";


    while (true) {
        int menu_choice;
        cout << "\nplease enter your choice: ";
        cin >> menu_choice;

        switch (menu_choice) {
        case 1:
            weekly_menu();
            break;
        case 2:
            discounts_for_sub();
            break;
        case 3:
            details();
            break;
        case 4:
            login_registration();
            break;
        default:
            cout << "please input a number \n"; // crashes when you try to input a letter/string
            continue;
        }
        break;
    }
}

